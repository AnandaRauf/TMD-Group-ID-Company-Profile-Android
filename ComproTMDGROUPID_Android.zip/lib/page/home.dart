import 'package:flutter/material.dart';
import 'package:get/get.dart';
//import 'package:fluttertoast/fluttertoast.dart';
//import 'package:convex_bottom_bar/convex_bottom_bar.dart';

import 'package:compro/page/webcompro.dart';
import 'package:compro/page/tentangkami.dart';
import 'package:compro/page/kontakkami.dart';
import 'package:compro/page/kproduk.dart';
import 'package:compro/page/brands.dart';
import 'package:compro/page/servicepricing.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Company Profile TMD Group ID'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildIconButton("Website", Icons.open_in_browser, () {
              Get.to(ComproWebMenuPage());
            }),
            buildIconButton("Info Brand", Icons.info, () {
              Get.to(InfoBrandScreen());
            }),
            buildIconButton("Service Pricing", Icons.attach_money, () {
              Get.to(ServicePricingScreen());
            }),
            buildIconButton("Catalog Product", Icons.info, () {
              Get.to(KProduk());
            }),
            buildIconButton("About Us", Icons.info_outline, () {
              Get.to(TentangKami());
            }),
            buildIconButton("Contact Us", Icons.contacts, () {
              Get.to(ContactUsScreen());
            }),
          ],
        ),
      ),
    );
  }

  Widget buildIconButton(String label, IconData icon, Function() onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Text(label),
    );
  }
}
