import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InfoBrandScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Info Brand',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Info Brand'),
        ),
        body: Center(
          child: Text('Info Brand Content'),
        ),
      ),
    );
  }
}
